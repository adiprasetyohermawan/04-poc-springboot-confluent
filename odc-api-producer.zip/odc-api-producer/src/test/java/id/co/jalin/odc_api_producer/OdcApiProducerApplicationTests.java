package id.co.jalin.odc_api_producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdcApiProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
